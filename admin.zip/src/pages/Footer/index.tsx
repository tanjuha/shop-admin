import React from 'react';
import "./footer.scss"

const Footer = () => {
    return (
        <div className="footer">
            2021 &#169; Admin
        </div>
    )
}

export default Footer;